import sys, os
sys.path.append(os.pardir)  # 부모 디렉터리의 파일을 가져올 수 있도록 설정
import numpy as np
import matplotlib.pyplot as plt
from dataset.mnist import load_mnist
from three_layer_net import ThreeLayerNet
from datetime import datetime
import sys, os
sys.path.append(os.pardir)  # 부모 디렉터리의 파일을 가져올 수 있도록 설정
from common.functions import *
(x_train,t_train),(x_test,t_test) = load_mnist(flatten=True,normalize=False,one_hot_label=True)
input_node = 784 # 입력층 노드의 개수
hidden_node = 392
output_node=10

w = np.random.randn(1, 784) #노드의 개수 : 784, 한 노드에 들어오는 입력값 : 1
b1 = np.zeros((1,784),float(64))# 바이어스는 한노드당 무조건 하나
#r1=np.zeros((784,1),dtype=np.float) #입력레이어의 배열

v = np.random.randn(hidden_node, 784) #노드의 개수 : 784, 한 노드에 들어오는 입력값 : 392
b2 = np.random.randn(392,1)# 바이어스는 한노드당 무조건 하나
#r2 = np.zeros((392,1),dtype=np.float) # 히든레이어의 배열

q = np.random.randn(output_node,392)
b3 = np.random.randn(10,1)
#result = np.zeros((10,1),dtype=np.float) #결과레이어의 배열
import time

final_acr = 0
learning_rate = 0.05
start_time = time.time()
for epoch in range(70):

    for data_num in range(60000):
        # 첫번째 데이터의 mlp라는 뜻
        x = x_train[data_num]
        y = sigmoid(x * w.T + b1.T)  # OK
        z=np.dot(y,v.T)+b2.T
        res = softmax(z)  # OK
        # 1X784인 w와 1X784인 x를 1x392인 노드로 만들어 내기 위해서 392x784로 x또는 w의 행렬을 바꾼다.


        storage = result.T * (1 - result.T) * e

        delta_q = learning_rate * result.T * (1 - result.T) * e * z
        delta_b3 = learning_rate * storage * 1

        q = q + delta_q.T
        b3 = b3 + delta_b3.T

        # Q1. 어떻게 역전파를 하는가? weight3의 값을 변경하면 weight1와 2의 값은 어떻게 변경?
        # Q2. 데이터 하나에 대하 재학습을 하고 6만번 돌려야되는지, 반대인지,,,

        stworage = np.dot(storage, q) * z.T * (1 - z.T)

        delta_v = learning_rate * stworage * y.T
        delta_b2 = learning_rate * stworage * 1

        v = v + delta_v.T
        b2 = b2 + delta_b2.T  # 편향은 바뀌면 안되는거 아닌가?

        sthreeage = np.dot(stworage, v) * y * (1 - y)

        delta_w = learning_rate * sthreeage * x
        delta_b1 = learning_rate * sthreeage * 1

        w = w + delta_w.T
        b1 = b1 + delta_b1.T

    accuracy_num = 0
    for index in range(10000):
        x = x_train[index]
        y = sigmoid(x * w.T + b1.T)  # OK
        z = sigmoid(np.dot(v, y.T) + b2)  # OK
        # 1X784인 w와 1X784인 x를 1x392인 노드로 만들어 내기 위해서 392x784로 x또는 w의 행렬을 바꾼다.

        result = sigmoid(np.dot(q, z) + b3)

        # print(np.argmax(test_target[index]), np.argmax(result))
        # print(result.max())

        if (np.argmax(t_test[index]) == np.argmax(result)):
            accuracy_num = accuracy_num + 1

        if (final_acr < accuracy_num):
            final_acr = accuracy_num
    if ((epoch) % 10 == 0):
        print('epoch :', epoch)
        print('time : ', time.time() - start_time)
        print('Accuracy count : ', accuracy_num)
        print('error : ', np.max(e))
        print('Accuracy rate  : ', (accuracy_num / 10000) * 100)
        print('-------------------------------------------------')

print('final accuracy is  : ', final_acr / 10000)