from tensorflow import keras
import numpy as np

mnist = keras.datasets.mnist
(train_images,train_labels),(test_images,test_labels)=mnist.load_data()


train_input=train_images/255
test_input=test_images/255

train_taget=keras.utils.to_categorical(train_labels)
test_target=keras.utils.to_categorical(test_labels)

model=keras.Sequential(
    [
        keras.layers.Flatten(input_shape=(28,28),name='Input'),
        keras.layers.Dense(128,activation='sigmoid',name='Hidden_1'),
        keras.layers.Dense(128, activation='sigmoid', name='Hidden_2'),
        keras.layers.Dense(128, activation='sigmoid', name='Hidden_3'),
        keras.layers.Dense(10, activation='sigmoid', name='output')

    ],
    name="mNISt_classfier"
)
model.summary()

model.compile(optimizer=keras.optimizers.SGD(lr=0.5),loss='mean_squared_error',metrics=['accuracy'])


model.fit(train_input,train_taget,epochs=20,verbose=2)

test_loss, test_acc = model.evaluate(test_input, test_target, verbose=2)
print('\nTest accuracy:', test_acc)
predictions = model.predict(test_input)
#%%