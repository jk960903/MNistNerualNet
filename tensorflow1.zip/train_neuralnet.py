# coding: utf-8
import sys, os
sys.path.append(os.pardir)  # 부모 디렉터리의 파일을 가져올 수 있도록 설정
import numpy as np
import matplotlib.pyplot as plt
from dataset.mnist import load_mnist
from three_layer_net import ThreeLayerNet
from datetime import datetime
# 데이터 읽기
(x_train, t_train), (x_test, t_test) = load_mnist(normalize=True, one_hot_label=True)
#validation data는 뒤에서 따로 설정 train data에서 추출을 할것인데 트레인데이터 55000index까지만 사용하고 validation추출을 55000이후의 것으로 추출
#train data 55000개 testdata 10000개 validation data 5000개
network = ThreeLayerNet(input_size=784, hidden_size=30, output_size=10)# 입력층 784개 은닉층 30 출력층 10 은닉층 개수가 올라갈수록 정확도는 올라가지만  속도는 저하
# 하이퍼파라미텨
iter = 12000  # 반복 횟수
train_size = 55000
batch_size = 100   # 배치 크기(한번에 가져와서 학습할 양)
learning_rate = 0.95 #학습률-> 점차 계속떨어짐

trainloss_list = []
validate_list=[]
trainacc_list = []
testacc_list = []

update_learning=learning_rate
# 1에폭당 반복 수
epoch = train_size/batch_size
pre_acc=0
epochnum=1
validate_mask=np.array(range(55000,60000,1)).reshape(5000)

starttime = datetime.now()
for i in range(iter):
    # 미니배치 획득
    batch_mask = np.random.choice(train_size, batch_size)
    x_batch = x_train[batch_mask]
    t_batch = t_train[batch_mask]
    vx_batch=x_train[validate_mask]
    vt_batch=t_train[validate_mask]

    # 기울기 계산
    grad = network.gradient(x_batch, t_batch)
    # 매개변수 갱신
    for key in ('W1', 'b1', 'W2', 'b2'):
        network.params[key] -= learning_rate * grad[key]
    
    # 학습 경과 기록
    loss = network.loss(x_batch, t_batch)
    trainloss_list.append(loss)
    # 1에폭당 정확도 계산
    if i % epoch == 0:
        train_acc = network.accuracy(x_train, t_train)
        vali_acc=network.accuracy(vx_batch,vt_batch)
        test_acc = network.accuracy(x_test, t_test)
        if vali_acc<pre_acc:
            learning_rate/=2
            pre_acc=vali_acc
        trainacc_list.append(train_acc)
        testacc_list.append(test_acc)
        validate_list.append(vali_acc)
        print(str(epochnum)+" "+"train acc, test acc validate| " + str(train_acc) + ", " + str(test_acc)+", "+str(vali_acc))
        epochnum=epochnum+1
        if test_acc>97 :
            break
endtime=datetime.now()
print("경과시간 :"+str((endtime-starttime).seconds))
print("에러 율 :"+ str(1-test_acc))
# 그래프  그리기
markers = {'train': 'o', 'test': 's'}
x = np.arange(len(trainacc_list))
plt.plot(x, trainacc_list, label='train acc')
plt.plot(x, testacc_list, label='test acc', linestyle='--')
plt.plot(x, validate_list,label='validate acc',linestyle='-.')
plt.xlabel("epochs")
plt.ylabel("accuracy")
plt.ylim(0, 1.0)
plt.legend(loc='lower right')
plt.show()
