# coding: utf-8
import numpy as np


def identity_function(x):
    return x


def step_function(x):
    return np.array(x > 0, dtype=np.int)


def sigmoid(x):#시그모이드 함수
    return 1 / (1 + np.exp(-x))
#시그모이드 미분
def sigmoid_grad(x):
    return (1.0 - sigmoid(x)) * sigmoid(x)


def relu(x):#렐루 함수
    return np.maximum(0, x)

#렐루 backward->relu미분
def relu_grad(x):
    grad = np.zeros(x)
    grad[x>=0] = 1
    return grad


def softmax(x):
    x = x.T
    x = x - np.max(x, axis=0)
    y = np.exp(x) / np.sum(np.exp(x), axis=0)
    return y.T

def mean_squared_error(y, t):#평균 제곱 오차
    return 0.5 * np.sum((y-t)**2)



